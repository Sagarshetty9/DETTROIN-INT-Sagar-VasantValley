import React from "react";

/**
 * Vasant Valley School — Hero Section
 * React + Tailwind CSS
 *
 * Fonts used (add to your index.html <head> or import in CSS):
 *   Playfair Display  -> headline serif + italic accent
 *   Inter              -> nav / body / labels
 *
 * <link rel="preconnect" href="https://fonts.googleapis.com">
 * <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
 *
 * In tailwind.config.js, extend fontFamily:
 *   theme: { extend: { fontFamily: {
 *     serif: ['"Playfair Display"', 'serif'],
 *     sans: ['Inter', 'sans-serif'],
 *   }}}
 */

const NAV_LINKS = [
  { label: "HOME", active: true },
  { label: "ABOUT" },
  { label: "ACADEMICS" },
  { label: "ADMISSIONS" },
  { label: "NEWS & EVENTS" },
  { label: "CONTACT" },
];

export default function Hero() {
  return (
    <section
      className="relative min-h-screen w-full overflow-hidden font-sans"
      style={{
        background:
          "radial-gradient(ellipse 80% 60% at 50% 20%, #7a1f1f 0%, #4a1010 45%, #1c0505 100%)",
      }}
    >
      {/* subtle top border accent */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-black/40" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-8 md:px-14 py-6">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 rotate-45 items-center justify-center border border-amber-400/80">
            <span className="-rotate-45 font-serif text-sm italic text-amber-400">
              v
            </span>
          </div>
          <span className="font-serif text-lg tracking-wide text-white">
            VASANT VALLEY
          </span>
        </div>

        {/* Links */}
        <ul className="hidden items-center gap-8 text-[13px] font-medium tracking-wider text-white/90 lg:flex">
          {NAV_LINKS.map((link) => (
            <li
              key={link.label}
              className={
                link.active
                  ? "cursor-pointer text-amber-400"
                  : "cursor-pointer transition-colors hover:text-amber-400"
              }
            >
              {link.label}
            </li>
          ))}
        </ul>

        {/* CTA outline button */}
        <button className="hidden h-10 w-28 rounded-sm border border-white/70 text-sm text-white/90 transition-colors hover:border-amber-400 hover:text-amber-400 md:block">
          Enroll
        </button>
      </nav>

      {/* Hero content */}
      <div className="relative z-10 mx-auto flex max-w-4xl flex-col items-center px-6 pt-20 pb-28 text-center md:pt-28">
        <p className="mb-6 text-xs font-semibold tracking-[0.3em] text-amber-400 md:text-sm">
          VASANT VALLEY SCHOOL
        </p>

        <h1 className="font-serif text-5xl font-bold leading-[1.05] text-white sm:text-6xl md:text-7xl">
          Where Excellence
        </h1>
        <h2 className="mt-1 font-serif text-5xl italic leading-[1.05] text-amber-400 sm:text-6xl md:text-7xl">
          Meets Possibility
        </h2>

        <p className="mt-8 max-w-2xl text-base leading-relaxed text-white/70 md:text-lg">
          Empowering students to discover their potential, shape their
          character, and lead with purpose in a changing world.
        </p>

        <div className="mt-10 flex flex-col gap-4 sm:flex-row">
          <button className="rounded-sm bg-amber-400 px-8 py-3.5 text-sm font-semibold text-[#3a0d0d] transition-transform hover:scale-[1.02] hover:bg-amber-300">
            Apply for Admissions
          </button>
          <button className="rounded-sm bg-white px-8 py-3.5 text-sm font-semibold text-[#7a1f1f] transition-transform hover:scale-[1.02] hover:bg-white/90">
            Discover Our School
          </button>
        </div>
      </div>
    </section>
  );
}
